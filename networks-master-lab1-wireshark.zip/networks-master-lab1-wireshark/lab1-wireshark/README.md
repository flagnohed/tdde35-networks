# Assignment 1 - Wireshark
* Include a report for the assignment in this folder as a *PDF or txt* file.
* The questions should be answered in chronological order.
* Provide screenshots if deemed necessary.
* Do not compress anything in this folder.